#include "openningMessage.h"
#include "QA.h"
int main() {
    sayHello();
    QA();
    return 0;
}